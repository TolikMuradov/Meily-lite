import { useEffect, useState, useRef } from 'react';
import CodeMirror from '@uiw/react-codemirror';
import { markdown } from '@codemirror/lang-markdown';
import { keymap, lineNumbers, highlightActiveLine } from '@codemirror/view';
import { defaultKeymap, history, historyKeymap } from '@codemirror/commands';
import { indentOnInput, foldGutter } from '@codemirror/language';
import '../css/MarkdownEditor.css';

const SLASH_COMMANDS = [
  { label: 'Todo', snippet: '- [ ] ' },
  { label: 'Table', snippet: '| Başlık | Başlık |\n|---|---|\n| Hücre | Hücre |' },
  { label: 'Mermaid', snippet: '```mermaid\ngraph TD;\nA-->B;\n```' },
  { label: 'H1', snippet: '# ' },
  { label: 'img', snippet: '![alt](url)' },
];

export default function MarkdownEditor({ content, setContent, editorRef }) {
  const [themeVars, setThemeVars] = useState({});
  const [showSlash, setShowSlash] = useState(false);
  const [selectedIndex, setSelectedIndex] = useState(0);
  const [query, setQuery] = useState('');
  const slashPos = useRef(null);

  const filteredCommands = SLASH_COMMANDS.filter(cmd =>
    cmd.label.toLowerCase().includes(query.toLowerCase())
  );

  const insertSnippet = (snippet) => {
    const view = editorRef.current;
    if (!view) return;
    const { state, dispatch } = view;
    const from = slashPos.current;
    const to = state.selection.main.head;

    if (from !== null) {
      dispatch({
        changes: { from, to, insert: snippet },
        selection: { anchor: from + snippet.length },
        scrollIntoView: true
      });
      view.focus();
      slashPos.current = null;
      setQuery('');
      setShowSlash(false);
    }
  };

  const editorExtensions = [
    markdown(),
    lineNumbers(),
    foldGutter(),
    highlightActiveLine(),
    indentOnInput(),
    history(),
    keymap.of([...defaultKeymap, ...historyKeymap])
  ];

  // ⚡️ Scroll Sync: scrollDOM + .cm-scroller üzerinden dinleyici bağla
  const bindScrollSync = (view) => {
    const sources = [view.scrollDOM, view.dom.querySelector('.cm-scroller')];
    sources.forEach((scroller) => {
      if (!scroller) return;

      const handleScroll = () => {
        const { scrollTop, scrollHeight, clientHeight } = scroller;
        if (!scrollHeight || !clientHeight || scrollHeight === clientHeight) return;

        const ratio = scrollTop / (scrollHeight - clientHeight);
        if (isNaN(ratio)) return;

        console.log("📤 SCROLL RATIO:", ratio);
        window.dispatchEvent(new CustomEvent("editor-scroll", { detail: ratio }));
      };

      scroller.addEventListener("scroll", handleScroll);
      console.log("✅ Scroll listener bağlandı:", scroller.className || "scrollDOM");
    });
  };

  useEffect(() => {
    const root = getComputedStyle(document.documentElement);
    setThemeVars({
      backgroundColor: root.getPropertyValue('transparent')?.trim(),
      color: root.getPropertyValue('--text')?.trim(),
    });
  }, [document.documentElement.getAttribute('data-theme')]);

  useEffect(() => {
    const view = editorRef.current;
    if (!view) return;

    const handleKeyDown = (e) => {
      if (!showSlash) return;

      if (e.key === 'ArrowDown') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev + 1) % filteredCommands.length);
      } else if (e.key === 'ArrowUp') {
        e.preventDefault();
        setSelectedIndex((prev) => (prev - 1 + filteredCommands.length) % filteredCommands.length);
      } else if (e.key === 'Enter') {
        e.preventDefault();
        e.stopPropagation();
        const cmd = filteredCommands[selectedIndex];
        if (cmd) insertSnippet(cmd.snippet);
      } else if (e.key === 'Escape') {
        setShowSlash(false);
      }
    };

    const dom = view.dom;
    dom.addEventListener('keydown', handleKeyDown);
    return () => dom.removeEventListener('keydown', handleKeyDown);
  }, [showSlash, selectedIndex, filteredCommands]);

  return (
    <div className="markdown-editor" style={{ ...themeVars }}>
      <CodeMirror
        value={content}
        height="100%"
        extensions={editorExtensions}
        theme="dark"
        lineNumbers={false}
        onCreateEditor={(view) => {
          editorRef.current = view;
        
          setTimeout(() => {
            const scroller = view.dom.querySelector('.cm-scroller');
            if (!scroller) return console.warn("cm-scroller bulunamadı");
        
            const handleScroll = () => {
              const max = scroller.scrollHeight - scroller.clientHeight;
              if (max <= 0) return;
        
              const ratio = scroller.scrollTop / max;
              console.log("📤 RATIO:", ratio);
              window.dispatchEvent(new CustomEvent("editor-scroll", { detail: ratio }));
            };
        
            scroller.addEventListener("scroll", handleScroll);
            console.log("✅ scroll listener aktif (cm-scroller)");
          }, 300);
        }}
        
        onChange={(value, viewUpdate) => {
          setContent(value);
          const view = editorRef.current;
          if (!view) return;

          const cursorPos = view.state.selection.main.head;
          const textBefore = view.state.sliceDoc(Math.max(0, cursorPos - 30), cursorPos);
          const match = /\/(\w*)$/.exec(textBefore);

          if (match) {
            slashPos.current = cursorPos - match[0].length;
            setQuery(match[1]);
            setShowSlash(true);
            setSelectedIndex(0);
          } else {
            setShowSlash(false);
          }
        }}
        style={{
         
          backgroundColor: 'transparent',
          color: 'inherit',
          border: 'none',
          outline: 'none',
        }}
      />

      {showSlash && (
        <div className="slash-command-popup">
          {filteredCommands.map((cmd, i) => (
            <div
              key={cmd.label}
              className={`slash-command-item ${i === selectedIndex ? 'selected' : ''}`}
              onMouseDown={() => insertSnippet(cmd.snippet)}
            >
              {cmd.label}
            </div>
          ))}
        </div>
      )}
    </div>
  );
}
